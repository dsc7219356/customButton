//
//  CustomButton.h
//  CustomButton
//
//  Created by dsc on 2017/12/26.
//  Copyright © 2017年 jsdtec. All rights reserved.
//

#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger,CustomButtonType) {
    CustomButtonLeftImageType,//左图标，右文字
    CustomButtonTopImageType,//上图标，下文字
    CustomButtonRightImageType//右图标，左文字
};
@interface CustomButton : UIView
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, assign) BOOL isShowSelectBackgroudColor;//是否展示点击效果

@property (nonatomic, copy)void(^touchBlock)(CustomButton *button);



/*
 初始化
 imageSize  图标大小
 isAutoWidth 是否根据文字长度自适应
 */
- (id)initWithFrame:(CGRect)frame
               type:(CustomButtonType)type
          imageSize:(CGSize)imageSize
          midmargin:(CGFloat)midmargin;

//点击响应
- (void)touchAction:(void(^)(CustomButton *button))block;


NS_ASSUME_NONNULL_END
@end
